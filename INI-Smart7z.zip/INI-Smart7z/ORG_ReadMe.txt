Smart7z

http://www.tc4shell.com/en/7zip/smart7z/
Copyright (C) 2018-19 Dec Software.

Smart7z is a plugin for the popular archiver 7-Zip. Smart7z provides flexible
settings when packing files into a .7z archive. For example, you can use
different compression methods for different files: LZMA for .jpg files, WavPack2
for .wav files, PPMD for text files, and LZMA2 for any other files. This way,
you can significantly improve the overall compression ratio.

INSTALLATION

The Smart7z distribution package is an ordinary Zip archive that contains the
following four files: 

    Smart7z.64.dll - the 64-bit version of the plugin
    Smart7z.32.dll - the 32-bit version of the plugin
    Smart7z.ini - the sample of setting file
    ReadMe.txt - the user instructions

To install the plugin into the 7-Zip installation folder, you need to create the
"Formats" subfolder. After that, copy Smart7z.64.dll or Smart7z.32.dll
(depending on your 7-Zip edition) and Smart7z.ini to that subfolder. If you do
that, each time you launch 7-Zip, it will automatically find Smart7z.

USAGE

AN IMPORTANT NOTE: Smart7z is only intended for creating new .7z files! If you
need to modify an existing .7z file created with Smart7z, you can easily open
that file in 7-Zip or in any other application that supports the .7z format.

AN IMPORTANT NOTE: Smart7z is an experimental plugin, so make sure that you test
each archive created with it! 

To pack a file using an algorithm supported by Smart7z, select the standard "Add
to archive..." command in 7-Zip. When the "Add to Archive" dialog box appears,
select the Smart7z format in the "Archive format" field. 

The plugin will analyze the files that you selected for packing into an archive
to select the best compression method for each file. 

Smart7z analyzes files based on the configuration file. You can specify a
configuration file to be used by adding the following parameter in the
"Parameters" field:

ini=filename

Here "filename" is the filename of the configuration file (without the path).
The filename must not contain any spaces, and the file must be located in the
plugin folder. If you omit the ini parameter, Smart7z will use the Smart7z.N.ini
file located in the plugin folder. N is a numeric representation of the
compression level that you selected. That is, Smart7z will use the Smart7z.9.ini
file for the Ultra level, the Smart7z.7.ini file for the Maximum level, etc. If
the compression level-specific configuration file is not found, the Smart7z.ini
file from the plugin folder will be used.

The configuration file is divided into sections. Each section describes a
specific compression method and looks as follows:

:default: m=%LZMA2%
*.pdf *.rtf
*.dat "some name*.dat"

The first line in the section marks the beginning of the section and consists of
the section name enclosed in colons and the compression settings for the files
assigned to the section. In this case, "default" is the section name, and
"m=%LZMA2%" is the compression settings; %LZMA2% is a variable (see the
description of variables below). If the "s" (solid block size) parameter is not
specified in the settings, its value will be set to 2 GB.

The rest of the section contains file masks. A line can contain any number of
masks delimited by single spaces. If you need to use a space in a mask, enclose
the mask in double quotes.

Any sections that have the same compression settings will be automatically
combined into one section, so feel free to create multiple sections with the
same settings.

You can temporarily disable a section by putting a hyphen at the beginning of
the first line of the section like this:

-:default: m=%LZMA2%

A section named "sorting" is the last section in the configuration file. That
section contains a list of file extensions. The "sorting" section defines how
files will be sorted by file extension, which is important. The earlier the
extension is mentioned in the "sorting" section, the higher the file with that
extension will be placed in the file list. If similar files (for example, MS
Office .doc and .xls files) are placed side-by-side, the overall compression
ratio will be better.

FILE GROUPING BY SECTIONS

When analyzing a file, Smart7z checks it in the following order:

    1. It checks if the filename (without the path) matches any mask listed in
    any section. If a match is found, the file will be assigned to the section
    containing the matching mask, and this step will be considered as completed.

    2. If no matching mask is found, Smart7z will analyze the content of the
    file. At this step, Smart7z can assign the file to a predefined section that
    has the default value (for more details about such sections, see below). For
    example, Smart7z can assign an .exe file to the "BCJ2" section and the .wav
    file to the "WavPack2" section. The current version of Smart7z can analyze
    the following types of files and assign them to different sections:

        PE files (.exe, .dll, .com, .sfx, etc.)
        ELF files
        Mach-O files
        Files that can be compressed with the WavPack plugin
        WAV files
        Text files

    3.If, having analyzed the content of the file, Smart7z could not assign it
    to any specific group, the file will be assigned to the "Default" section.

When all the files have been analyzed, they will be packed based on the settings
specified in the sections they’ve been assigned to.

File content analysis is a much more resource-intensive operation than filename
matching to file masks, so we recommend that you specify as many masks with
known extensions as you can in the configuration sections in order to reduce the
overall files analysis time. However, you should never add any masks containing
the extensions of files whose type is determined based on file content analysis
(.exe, .dll, .wav, etc.).

VARIABLES

Some variables have been predefined to make it easier for you to configure
compression settings. You can add new variables, too. Variables are used to
describe compression settings.

The following variables are predefined:

Name                         Default value
        64-bit version of Smart7z  32-bit version of Smart7z
%LZMA%  LZMA:x9:mt2:d1536m         LZMA:x9:mt2:d128m
%LZMA2% LZMA2:x9:mt2:d1536m        LZMA2:x9:mt2:d128m
%PPMD%  PPMd:x9:mem1g              PPMd:x9:mem1g

Example:

In the 64-bit version of Smart7z, the line

:default: m=%LZMA2%

will be interpreted as

:default: m=LZMA2:x9:mt2:d1536m

To set a new value or add a new variable, add the following line at the
beginning of the .ini file:            

::SET %LZMA% NewValue

Here %LZMA% is a variable, and NewValue is its new value. NewValue cannot
contain another variable.

PREDEFINED SECTIONS

Predefined sections are used to match files that are subject to file content
analysis. If sections with the following names do not exist in the .ini file,
they will be created automatically:

Section name                 Applies to                       Default settings
Default                      Default compression              %LZMA2%
Txt                          Text files                       %PPMD%
BCJ2                         Files containing executable      m0=BCJ2 m1=%LZMA2% m2=LZMA:d20:fb128:lc0:lp2 m3=LZMA:d20:fb128:lc0:lp2 mb0s0:1 mb0s1:2 mb0s2:3
                             code for Intel-compatible
                             processors
ARM                          Files containing executable      f=ARMT m=%LZMA2%:lc2:lp1
                             code for ARM processors
ARMT                         Files containing executable      f=ARMT m=%LZMA2%:lc2:lp1
                             code for ARM Thumb-2 processors
IA64                         Files containing executable      f=IA64 m=%LZMA2%:pb4:lc0:lp4
                             code for Intel 64 processors
SPARC                        Files containing executable      f=SPARC m=%LZMA2%:lc1:lp2
                             code for SPARC processors
PPC                          Files containing executable      f=PPC m=%LZMA2%:lc1:lp2
                             code for PowerPC processors
WavPack2                     Uncompressed PCM audio files     m0=WavPack2:x9 m1=lzma:d20 mb0s1:1
Delta2                                                        f=delta:2 m=%LZMA2%:lc2:lp1
Delta4                                                        f=delta:4 m=%LZMA2%:lc1:lp2
Delta8                                                        f=delta:8 m=%LZMA2%:pb3:lc0:lp3
Delta16                                                       f=delta:16 m=%LZMA2%:pb4:lc0:lp4
DeltaN, where N is a number                                   f=delta:N m=%LZMA2%
from 1 to 256, except for 2,
4, 8, and 16

USING ADDITIONAL CODECS

If the WavPack plugin is detected, it will be automatically used to compress PCM
audio files. You can disable that codec by adding the following line at the
beginning of the .ini file:

::DISABLE WavPack2